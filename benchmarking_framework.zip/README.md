# Experimental Framework
The experimental framework is a framework that allows automatic execution of
experiment and related data collection.


## How to install the framework and the dependencies
In order to make the framework working it is necessary to install a set of
dependencies.
The user can follow this short tutorial on how to do this, reported in the
following.

    $ git clone framework_repository //TODO: Fix This

Enter the directory

    $ cd benchmarking_framework

Make a copy of the configuration file
    $ cp _conf.cfg conf.cfg

Edit the configuration file according to the specific system.
Specify, into the configuration, the heat template to be used for the test

// TODO: Fix this
(for example: "template_base_name = VTC_base_single_vm_wait.tmp")

Create a directory called "programs".
cd into it and download the packet generator from git:

    $ git clone https://github.com/pktgen/Pktgen-DPDK.git

After the download enters the Pktgen-DPDK dir and setup the packet generator
according to its README.

After compiling DPDK and Pktgen-DPDK as specified in the README,
it is necessary to load the DPDK kernel module.

// TODO: Add how to load the module

Some parameters related to the DPDK packet generator will be needed in the \
configuration file. After the installation it is going to be necessary
to specify in the configuration file whether the user wants to use a packet
generator or not, specifying one of the following options:

        "packet_generator = dpdk_pktgen"
        "packet_generator = none"


If yes, the installation directory for DPDK and Pktgen-DPDK is required, along
with the program name (the executable script that runs the packet generator).
For example:

        "pktgen_directory = /home/user/benchmarking_framework/programs/Pktgen-DPDK/dpdk/examples/pktgen/"
        "dpdk_directory = /home/user/benchmarking_framework/programs/Pktgen-DPDK/dpdk/"
        "program_name = app/app/x86_64-native-linuxapp-gcc/pktgen"

Also some parameters to configure the packet gen behaviour need to be specified:

        "coremask = 1f"
        "memory_channels = 3"


Finally, the bus addresses of the NICs to be used are required:

        "bus_slot_nic_1 = 01:00.0"
        "bus_slot_nic_2 = 01:00.1"


Before to run the framework it is required to install some python dependencies:

    $ sudo apt-get install python-dev
    $ sudo apt-get install python-pip
    $ sudo pip install wrapt
    $ sudo pip install python-heatclient
    $ sudo apt-get install tcpreplay


In order to be able to run experiments varying the flavour of a workload,
it could be necessary to install the python module at:

    https://github.com/openstack/heat/blob/master/heat/engine/resources/openstack/nova/nova_flavor.py

This will support the creation on the fly of Nova Flavors.


In order to enable SR-IOV interfaces on the physical NIC, compatible nic is required.
The NIC needs also to be configured properly.

After NIC configuration, a proper configuration of openstack is required.
See at: https://wiki.openstack.org/wiki/SR-IOV-Passthrough-For-Networking
and also:




## How to run benchmarking framework

From the main directory of the framework

    $ python setup.py install

To run the benchmarking framework it is necessary to run the following as
super user:

    $ python VNFBench.py


## How to run benchmarking framework tests

It is required to install dependecies in order to run the tests.
The commands for this on Ubuntu are in the following:

    $ pip install mock
    $ yum install python-mock

To run the tests simply call the script:

    $ ./bin/run_tests.sh

