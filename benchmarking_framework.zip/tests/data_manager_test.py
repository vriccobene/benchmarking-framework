# Copyright (c) 2015 Intel Research and Development Ireland Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

__author__ = 'gpetralx'

import unittest
from experimental_framework import data_manager
import os


class TestDataManager(unittest.TestCase):
    """
    Test the data manager
    """

    def setUp(self):
        self.dm = data_manager.DataManager('tests/data/experiments')

    def tearDown(self):
        pass

    def test_create_new_experiment_for_success(self):
        self.dm.create_new_experiment('experiment_1')
        self.assertIn('experiment_1', self.dm.experiments.keys())

    def test_metadata_for_success(self):
        metadata = {
            'item_1': 'value_1',
            'item_2': 'value_2',
            'item_3': 'value_3'
        }

        with self.assertRaises(ValueError):
            self.dm.add_metadata('experiment_1', metadata)

        with self.assertRaises(ValueError):
            self.dm.get_metadata('experiment_1')

        self.dm.create_new_experiment('experiment_1')
        self.dm.add_metadata('experiment_1', metadata)
        self.assertDictEqual(metadata, self.dm.get_metadata('experiment_1'))

    def test_configuration_for_success(self):
        configuration = {
            'item_1': 'value_1',
            'item_2': 'value_2',
            'item_3': 'value_3'
        }

        with self.assertRaises(ValueError):
            self.dm.add_configuration('experiment_1', configuration)

        with self.assertRaises(ValueError):
            self.dm.get_configuration('experiment_1')

        self.dm.create_new_experiment('experiment_1')
        self.dm.add_configuration('experiment_1', configuration)
        self.assertDictEqual(configuration, self.dm.get_configuration('experiment_1'))

    def test_add_benchmark_for_success(self):
        self.dm.create_new_experiment('experiment_1')
        self.dm.add_benchmark('experiment_1', 'benchmark_1')
        self.assertIn('benchmark_1', self.dm.experiments['experiment_1'].get_benchmarks())

    def test_add_data_points_for_success(self):
        self.dm.create_new_experiment('experiment_1')
        with self.assertRaises(ValueError):
            self.dm.add_data_points('experiment_1', 'benchmark_1', list())
        self.dm.add_benchmark('experiment_1', 'benchmark_1')

        data_point_1 = {
            'point_1': 'value_1',
            'point_2': 'value_2',
            'point_3': 'value_3'
        }

        data_point_2 = {
            'point_4': 'value_4',
            'point_5': 'value_5',
            'point_6': 'value_6'
        }

        data_point_list_1 = [data_point_1, data_point_2]

        self.dm.add_data_points('experiment_1', 'benchmark_1', data_point_list_1)
        self.assertListEqual(data_point_list_1, self.dm.experiments['experiment_1'].get_data_points('benchmark_1'))

        data_point_list_2 = [data_point_2]
        self.dm.create_new_experiment('experiment_2')
        self.dm.add_benchmark('experiment_2', 'benchmark_2')
        self.dm.add_data_points('experiment_2', 'benchmark_2', data_point_2)
        self.assertListEqual(data_point_list_2, self.dm.experiments['experiment_2'].get_data_points('benchmark_2'))

    def test_get_list_experiment_names_for_success(self):
        experiments = list()
        self.assertListEqual(experiments, self.dm.get_list_experiment_names())
        self.dm.create_new_experiment('experiment_1')
        experiments.append('experiment_1')
        self.dm.create_new_experiment('experiment_2')
        experiments.append('experiment_2')
        self.assertListEqual(experiments, self.dm.get_list_experiment_names())

    def test_close_experiment_for_success(self):
        os.system("rm -rf tests/data/experiments/experiment_1")
        with self.assertRaises(ValueError):
            self.dm.close_experiment('experiment_1')

        self.create_one_experiment_one_benchmark()
        self.dm.close_experiment('experiment_1')

        test_files = 'tests/data/test_experiments/experiment_1/'
        generated_files = 'tests/data/experiments/experiment_1/'

        for dirname, dirnames, filenames in os.walk(test_files):
            for filename in filenames:
                with open(test_files + filename) as test:
                    with open(generated_files + filename) as generated:
                        self.assertListEqual(test.readlines(), generated.readlines())

        os.system("rm -rf tests/data/experiments/experiment_1")

    def test_generate_result_csv_file_for_success(self):
        os.system("rm -rf tests/data/experiments/results_benchmark_1.csv")
        self.create_two_experiments_one_benchmark()

        self.dm.generate_result_csv_file()

        expected_file = 'tests/data/test_experiments/results_benchmark_1.csv'
        result_file = 'tests/data/experiments/results_benchmark_1.csv'
        with open(expected_file) as test:
            with open(result_file) as generated:
                self.assertListEqual(test.readlines(), generated.readlines())

        os.system("rm -rf tests/data/experiments/results_benchmark_1.csv")

    def test_get_all_benchmarks_for_success(self):
        self.assertSetEqual(set(), self.dm.get_all_benchmarks())
        expected = set()
        expected.add('benchmark_1')
        expected.add('benchmark_2')
        self.dm.create_new_experiment('experiment_1')
        self.dm.add_benchmark('experiment_1', 'benchmark_1')
        self.dm.add_benchmark('experiment_1', 'benchmark_2')
        self.dm.create_new_experiment('experiment_2')
        self.dm.add_benchmark('experiment_2', 'benchmark_1')
        self.assertSetEqual(expected, self.dm.get_all_benchmarks())

    def test_write_experiment_csv_file_for_success(self):
        os.system("rm -rf tests/data/experiments/experiment_1")
        with self.assertRaises(ValueError):
            self.dm.close_experiment('experiment_1')

        self.create_one_experiment_one_benchmark()

        os.system("mkdir -p tests/data/experiments/experiment_1/")

        self.dm.write_experiment_csv_file('experiment_1', None)

        test_files = 'tests/data/test_experiments/experiment_1/benchmark_1.csv'
        generated_files = 'tests/data/experiments/experiment_1/benchmark_1.csv'
        with open(test_files) as test:
            with open(generated_files) as generated:
                self.assertListEqual(test.readlines(), generated.readlines())

        os.system("rm -rf tests/data/experiments/experiment_1")

    def test_is_experiment_present_for_success(self):
        self.assertFalse(self.dm.is_experiment_present('experiment_1'))
        self.dm.create_new_experiment('experiment_1')
        self.assertTrue(self.dm.is_experiment_present('experiment_1'))

    def test_is_benchmark_present_for_success(self):
        self.assertFalse(self.dm.is_benchmark_present('experiment_1', 'benchmark_1'))
        self.dm.create_new_experiment('experiment_1')
        self.assertFalse(self.dm.is_benchmark_present('experiment_1', 'benchmark_1'))
        self.dm.add_benchmark('experiment_1', 'benchmark_1')
        self.assertTrue(self.dm.is_benchmark_present('experiment_1', 'benchmark_1'))

    def test_get_all_titles_for_success(self):

        self.create_two_experiments_one_benchmark()

        expected = ['conf_5', 'conf_4', 'conf_6', 'conf_1', 'conf_3', 'conf_2', 'point_12',
                    'point_10', 'point_11', 'point_4', 'point_5', 'point_6', 'point_8',
                    'point_9', 'point_7', 'point_1', 'point_2', 'point_3']

        self.assertListEqual(expected, self.dm._get_all_titles('benchmark_1'))

    def test_get_data_for_csv_for_success(self):
        self.create_one_experiment_one_benchmark()
        titles = self.dm._get_all_titles('benchmark_1')
        expected = [
            ['conf_value_1', 'conf_value_3', 'conf_value_2', '?', '?', '?', 'value_1', 'value_2', 'value_3', 'value_1'],
            ['conf_value_1', 'conf_value_3', 'conf_value_2', 'value_4', 'value_5', 'value_6', '?', '?', '?', 'value_1']
        ]
        titles.append('item_1')
        self.assertListEqual(expected, self.dm._get_data_for_csv(self.dm.experiments['experiment_1'], 'benchmark_1', titles))

    def create_one_experiment_one_benchmark(self):
        self.metadata = {
            'item_1': 'value_1',
            'item_2': 'value_2',
            'item_3': 'value_3'
        }

        self.configuration = {
            'conf_1': 'conf_value_1',
            'conf_2': 'conf_value_2',
            'conf_3': 'conf_value_3'
        }

        self.dm.create_new_experiment('experiment_1')
        self.dm.add_metadata('experiment_1', self.metadata)
        self.dm.add_configuration('experiment_1', self.configuration)
        self.dm.add_benchmark('experiment_1', 'benchmark_1')

        self.data_point_1 = {
            'point_1': 'value_1',
            'point_2': 'value_2',
            'point_3': 'value_3'
        }

        self.data_point_2 = {
            'point_4': 'value_4',
            'point_5': 'value_5',
            'point_6': 'value_6'
        }

        self.data_point_list_1 = [self.data_point_1, self.data_point_2]

        self.dm.add_data_points('experiment_1', 'benchmark_1', self.data_point_list_1)

    def create_two_experiments_one_benchmark(self):
        self.metadata_1 = {
            'metadata_1': 'metadata_value_1',
            'metadata_2': 'metadata_value_2',
            'metadata_3': 'metadata_value_3'
        }

        self.configuration_1 = {
            'conf_1': 'conf_value_1',
            'conf_2': 'conf_value_2',
            'conf_3': 'conf_value_3'
        }

        self.dm.create_new_experiment('experiment_1')
        self.dm.add_metadata('experiment_1', self.metadata_1)
        self.dm.add_configuration('experiment_1', self.configuration_1)
        self.dm.add_benchmark('experiment_1', 'benchmark_1')

        self.data_point_1 = {
            'point_1': 'value_1',
            'point_2': 'value_2',
            'point_3': 'value_3'
        }

        self.data_point_2 = {
            'point_4': 'value_4',
            'point_5': 'value_5',
            'point_6': 'value_6'
        }

        self.data_point_list_1 = [self.data_point_1, self.data_point_2]

        self.dm.add_data_points('experiment_1', 'benchmark_1', self.data_point_list_1)

        self.metadata_2 = {
            'metadata_4': 'metadata_value_4',
            'metadata_5': 'metadata_value_5',
            'metadata_6': 'metadata_value_6'
        }

        self.configuration_2 = {
            'conf_4': 'conf_value_4',
            'conf_5': 'conf_value_5',
            'conf_6': 'conf_value_6'
        }

        self.dm.create_new_experiment('experiment_2')
        self.dm.add_metadata('experiment_2', self.metadata_2)
        self.dm.add_configuration('experiment_2', self.configuration_2)
        self.dm.add_benchmark('experiment_2', 'benchmark_1')

        self.data_point_3 = {
            'point_7': 'value_7',
            'point_8': 'value_8',
            'point_9': 'value_9'
        }

        self.data_point_4 = {
            'point_10': 'value_10',
            'point_11': 'value_11',
            'point_12': 'value_12'
        }

        self.data_point_list_2 = [self.data_point_3, self.data_point_4]

        self.dm.add_data_points('experiment_2', 'benchmark_1', self.data_point_list_2)