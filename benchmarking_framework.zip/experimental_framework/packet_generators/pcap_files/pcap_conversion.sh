#!/bin/bash

MAC_MULTICAST_ADDRESS="ff:ff:ff:ff:ff:ff"

# Change MAC Address source of the packet generator
#bittwiste -I PacketGenerators/pcap_files/igmp_1006.pcap -O PacketGenerators/pcap_files/a.pcap -T eth -s $MAC_MULTICAST_ADDRESS

# Change MAC Address source of the packet generator
#bittwiste -I PacketGenerators/pcap_files/a.pcap -O PacketGenerators/pcap_files/igmp_1006_dpdk.pcap -T eth -d "01:00:5E:40:10:01"
#bittwiste -I PacketGenerators/pcap_files/a.pcap -O PacketGenerators/pcap_files/igmp_1006_dpdk.pcap -T eth -d "ff:ff:ff:ff:ff:ff"

# Change the destination MAC Address to the Multicast MAC address
bittwiste -I PacketGenerators/pcap_files/solution.pcap -O PacketGenerators/pcap_files/a.pcap -T eth -d $MAC_MULTICAST_ADDRESS
#bittwiste -I PacketGenerators/pcap_files/a.pcap -O PacketGenerators/pcap_files/packet_1280_dpdk.pcap -T ip -d 8.1.1.1

tcprewrite --dstipmap="224.192.16.1:8.1.1.1" --infile=PacketGenerators/pcap_files/a.pcap --outfile=PacketGenerators/pcap_files/packet_1280_dpdk.pcap