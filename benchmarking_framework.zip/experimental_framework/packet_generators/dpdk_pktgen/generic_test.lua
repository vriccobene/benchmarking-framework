--
-- Dummy Traffic Generation for 40 seconds
--

package.path = package.path ..";?.lua;test/?.lua;app/?.lua;../?.lua"
require "Pktgen";

local sendport = "0";
local recvport = "1";

rate = 50;
pktgen.start(sendport);
pktgen.set(sendport, "rate", rate);
sleep(40);
pktgen.stop(sendport);
os.exit(1);