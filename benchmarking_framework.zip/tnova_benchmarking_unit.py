"""
This file contains the code to deploy the VNF and all the other elements needed
"""

__author__ = "vmriccox"

from experimental_framework import common
import experimental_framework.benchmarking_unit as bench


class TnovaBenchmarkingUnit(bench.BenchmarkingUnit):
    """
    Management of the all Benchmarking process
    """

    def __init__(self):
        bench.BenchmarkingUnit.__init__(self)
        self.destination_template = common.CONF_FILE.get_variable('General', 'destination_template')
        pass

    def initialize(self):
        """
        Deploys a destination for the TNOVA experiment
        :return: None
        """
        bench.BenchmarkingUnit.initialize(self)
        if not common.DEBUG:
            common.LOG.info('Deploy the destination')
            common.DEPLOYMENT_UNIT.deploy_destination('tnova_destination', self.template_dir + self.destination_template)

    def finalize(self):
        if not common.DEBUG:
            common.DEPLOYMENT_UNIT.destroy_heat_template('tnova_destination')
        bench.BenchmarkingUnit.finalize(self)

    def run_benchmarks(self):
        bench.BenchmarkingUnit.run_benchmarks(self)