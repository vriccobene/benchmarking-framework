'''
Smart Deployment
'''

__author__ = 'vmriccox'
