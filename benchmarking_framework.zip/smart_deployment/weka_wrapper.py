__author__ = 'vmriccox, add_giuseppe'

import sys
sys.path.append('../..')
# from smart_deployment.decision_maker import DecisionTreeNode

import subprocess
import re
import decision_maker as dm
# from benchmark_framework import common


class WekaWrapper():

    @staticmethod
    def _extract_J48_data(line):
        leaf_pattern = "[\t.\s.|]*(?P<metric>.[a-z0-9._.-]*)\s(?P<operator>.[<.=.>]*)" \
                       "\s(?P<threshold>.[0-9.\\..E]*)[:]?[\s]?'?(?P<exit_status>.[a-z.]*)'?"
        no_leaf_pattern = "[\t.\s.|]*(?P<metric>.[a-z0-9._.-]*)\s(?P<operator>.[<.=.>]*)" \
                          "\s(?P<threshold>.[0-9.\\..E]*)[:]?[\s]?"
        result = None
        depth = line.count('|')
        line = line.replace("|   ", "")
        pattern = re.compile(leaf_pattern)
        match = pattern.match(line)
        if match:
            metric = match.group("metric")
            operator = match.group("operator")
            threshold = float(match.group("threshold"))
            exit_status = match.group('exit_status')
            result = (depth, metric, operator, threshold, exit_status)
        else:
            pattern = re.compile(no_leaf_pattern)
            match = pattern.match(line)
            if match:
                metric = match.group("metric")
                operator = match.group("operator")
                threshold = float(match.group("threshold"))
                result = (depth, metric, operator, threshold)
        return result

    @staticmethod
    def _find_between(s, first, last ):
        try:
            start = s.index( first ) + len( first )
            end = s.index( last, start )
            return s[start:end]
        except ValueError:
            return ""

    # decision_tree = 'vnic-4 <= 1 \
    # |   vnic-3 <= 1 \
    # |   |   vnic-1 <= 1: less (549.0/1.0) \
    # |   |   vnic-1 > 1: 400-Mbps (752.0/227.0) \
    # |   vnic-3 > 1: less (1442.0/60.0) \
    # vnic-4 > 1 \
    # |   vnic-5 <= 1 \
    # |   |   vnic-3 <= 1 \
    # |   |   |   vnic-1 <= 1: 800-Mbps (275.0/41.0) \
    # |   |   |   vnic-1 > 1: less (411.0/221.0) \
    # |   |   vnic-3 > 1: less (752.0/10.0) \
    # |   vnic-5 > 1: 3-Gbps (1230.0/318.0)'

    @staticmethod
    def extract_decision_tree():

        # TODO: Change the parameters of the algorithm dynamically according to the number of element in the overall.csv

        proc = subprocess.Popen(["./analyse_csv.sh overall.csv"], stdout=subprocess.PIPE, shell=True)
        (out, err) = proc.communicate()

        decision_tree = WekaWrapper._find_between(out, "------------------\n", "\n\nNumber of Leaves")
        root = dm.DecisionTreeNode()
        current_node = root
        current_level = -1
        rules = list()
        for line in decision_tree.split('\n'):
            line = line.strip()
            if line != '':
                rule = WekaWrapper._extract_J48_data(line)
                if not rule:
                    return None

                n = dm.DecisionTreeNode(variable_name=rule[1], condition_sign=rule[2], variable_value=rule[3], network_intent=0)

                if current_level < rule[0]:
                    current_node.add_child(n)
                    current_node = n
                    current_level += 1

                elif current_level == rule[0]:
                    current_node = current_node.get_parent()
                    current_node.add_child(n)
                    current_node = n

                elif current_level > rule[0]:
                    for i in range(0, current_level - rule[0] + 1):
                        current_node = current_node.get_parent()
                        current_level -= 1
                    current_node.add_child(n)
                    current_node = n

        leaves = root.get_leaves()
        for leaf in leaves:
            print leaf.get_path()

        return root
