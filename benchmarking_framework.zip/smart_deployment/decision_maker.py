__author__ = 'vmriccox'

import re
import sys
import os
import shutil

sys.path.append('../..')
from experimental_framework import common


class InputValidationException(Exception):
    pass


class DecisionTreeNode:
    """
    This class represents the element of a decision tree
    """

    def __init__(self, variable_name=None, condition_sign=None, variable_value=None, network_intent=None):
        """

        :param variable_name: name of the variable to be represented by this node (string)
        :param condition_sign: mathematical sign for this node (=, <, >, <=, >=, ...) (string)
        :param variable_value: Value of the variable (string)
        :param network_intent: Network performance intent related to this node (string)
        :return: None
        """
        # TODO: input validation (especially for network_intent)
        self.up = None
        self.down = []
        self.variable_name = variable_name
        self.condition_sign = condition_sign
        self.variable_value = variable_value
        self.network_intent = network_intent
        self.cost = 0

    def add_child(self, node):
        """
        Adds a child to the current node
        :param node: child to be added
        :return: None
        """
        node.up = self
        self.down.append(node)

    def set_variable_name(self, name):
        """
        Sets the variable name of the node
        :param name: Name of the variable
        :return: None
        """
        self.variable_name = name

    def set_variable_value(self, value):
        """
        Sets the value of the variable
        :param value: Value to be set
        :return: None
        """
        self.variable_value = value

    def set_cost(self, cost):
        """
        Sets the cost to the node
        :param cost: Cost to be set
        :return: None
        """
        # TODO: Input validation
        self.cost = cost

    def get_parent(self):
        """
        Returns the parent of the node
        :return: DecisionTreeNode
        """
        return self.up

    def get_children(self):
        """
        Returns the children of the node
        :return: list of DecisionTreeNode
        """
        if len(self.down) == 0:
            return []
        return self.down

    def get_variable_name(self):
        """
        Returns the variable name
        :return: string
        """
        return self.variable_name

    def get_variable_value(self):
        """
        Returns the variable value
        :return: string
        """
        return self.variable_value

    def get_cost(self):
        """
        Returns the cost related to the node
        :return: int
        """
        return self.cost

    def get_network_intent(self):
        """
        Returns the network intent for the node
        :return: string
        """
        return self.network_intent

    def get_path(self):
        '''
        Gets the path from the node up to the root of the graph.
        :return: list of DecisionTreeNode
        '''
        ret_val = []
        if not self.up:
            ret_val.append(self)
            return ret_val
        for node in self.up.get_path():
            ret_val.append(node)
        ret_val.append(self)
        return ret_val

    def get_overall_cost(self):
        """
        Calculates and returns the overall cost of a configuration
        :return: int
        """
        cost = 0
        path = self.get_path()
        for node in path:
            cost += node.get_cost()
        return cost

    def __str__(self):
        """
        Converts the node to a string
        :return: string
        """
        return str(self.variable_name) + " " + str(self.condition_sign) + " " + str(self.variable_value)

    def __repr__(self):
        """
        Converts the node to a string
        :return: string
        """
        if not self.variable_name:
            return "root"
        if not self.network_intent:
            return str(self.variable_name) + " " + str(self.condition_sign) + " " + str(self.variable_value)
        return str(self.variable_name) + " " + str(self.condition_sign) + " " + str(self.variable_value) + " (" + \
            str(self.network_intent) + ")"

    def get_leaves(self):
        """
        Returns the leaves of the tree
        :return: list of DecisionTreeNode
        """
        leaves = list()
        children = self.get_children()
        if len(children) == 0:
            leaves.append(self)
            return leaves
        for child in children:
            cl = child.get_leaves()
            for l in cl:
                leaves.append(l)
        return leaves


class DecisionMaker(object):
    """
    """

    def __init__(self):
        self.decision_trees = dict()
        self.variables_values = None
        self.variables_costs = None
        self._load_configuration_cost_from_config_file()
        self._normalise_cost_configuration()

    def add_decision_tree(self, vnf_id, decision_tree):
        '''
        For the specified VNF ID, add a decision tree into the internal database
        :param vnf_id: ID of the VNF the decision tree is related to
        :param decision_tree: decision tree to be included in the decision making process
        :return: None
        '''
        if not isinstance(decision_tree, DecisionTreeNode):
            raise InputValidationException("The provided decisioin Tree is not valid")
        if not isinstance(vnf_id, int) or vnf_id <= 0:
            raise InputValidationException("The VNF ID has to be an integer higher than zero")

        # Calculate the cost for each configuration of the tree
        leaves = decision_tree.get_leaves()
        for configuration in leaves:
            path = configuration.get_path()
            for node in path:
                if node.get_variable_name():
                    print node.get_variable_name()
                    print node.get_variable_value()
                    cost = self._get_cost_for_variable(node.get_variable_name(), node.get_variable_value())
                    node.set_cost(cost)
        self.decision_trees[vnf_id] = decision_tree

    def deploy_vnf(self, vnf_id, network_intent):
        '''
        Deploys the required vnf to accomplish the specified network intent
        :param vnf_id: ID of the VNF to be deployed
        :param network_intent: network intent to be guaranteed by the VNF
        :return: None
        '''
        if not isinstance(network_intent, int) and network_intent <= 0:
            raise InputValidationException("The network intent has to be an integer higher than 0")
        configuration = self._get_best_configuration(vnf_id, network_intent)
        best_heat_template = self._get_best_heat_template(vnf_id, configuration)

        print best_heat_template

        # TODO: Deploy the best_heat_template using Heat
        pass

    def _get_best_configuration(self, vnf_id, network_intent):
        """
        Gets the heat template for the specified
        :param vnf_id: ID of the VND
        :param network_intent: Required network intent
        :return: Returns the heat template that guarantees the specified network intent
        """
        decision_tree = self.decision_trees[vnf_id]
        leaves = decision_tree.get_leaves()
        candidate = None
        candidate_cost = sys.maxint
        for leaf in leaves:
            if leaf.get_network_intent() >= network_intent and leaf.get_overall_cost() < candidate_cost:
                candidate_cost = leaf.get_overall_cost()
                candidate = leaf
        # get the most efficient configuration required to support the specified network intent
        if not candidate:
            return list()
        return candidate.get_path()

    def _get_best_heat_template(self, vnf_id, configuration):
        """
        Given a configuration (intended as a list of DecisionTreeNodes), this method gets the correspondent heat
        template.
        :param configuration: path of the decision tree (i.e. list of DecisionTreeNodes) representing the configuration
        :return: Heat template representing the requested configuration
        """
        # Load some vars from config file
        new_template = 'vnf_%d_temp.yaml' % vnf_id
        template_base_name = common.CONF_FILE.get_variable('General', 'template_base_name')
        template_dir = common.CONF_FILE.get_variable('General', 'template_dir')
        # prepare the heat template
        if os.path.isabs(template_base_name):
            base_template = template_base_name
        else:
            base_template = template_dir + template_base_name
        shutil.copy(base_template, new_template)
        # get the configuration corresponding to the minimal cost
        minimal_configuration = self._get_minimal_cost_configuration()
        # Starting from the minimal configuration, replace in it only the elements necessary to the Network Intent
        for c in minimal_configuration:
            for cc in configuration:
                if cc.get_variable_name() == c.get_variable_name():
                    c.set_variable_value(cc.get_variable_value())
        # Generation of the template corresponding to the obtained configuration
        for var in minimal_configuration:
            if var.get_variable_name():
                common.replace_in_file(new_template, "#" + var.get_variable_name(), var.get_variable_value())
        return new_template

    def _get_minimal_cost_configuration(self):
        '''
        Returns the configuration of the system corresponding to the lower cost
        :return: list of DecisionTreeNode
        '''
        configuration = list()
        for var in self.variables_values:
            if self.variables_costs[var]:
                minimum = min(self.variables_costs[var])
                index = self.variables_costs[var].index(minimum)
                configuration.append(DecisionTreeNode(var, '=', self.variables_values[var][index]))
            else:
                configuration.append(DecisionTreeNode(var, '=', self.variables_values[var][0]))
        return configuration

    def _load_configuration_cost_from_config_file(self):
        '''
        Loads from the conf file the cost of all the different configuration parameters correspondent to their values
        :return: None
        '''
        # Initialise variables
        self.variables_values = dict()
        self.variables_costs = dict()
        types = dict()
        # Load variables and costs from the configuration file
        all_variables = common.CONF_FILE.get_variable_list('Experiment-VNF')
        for var in all_variables:
            v = common.CONF_FILE.get_variable('Experiment-VNF', var)
            type = re.findall(r'@\w*', v)
            values = re.findall(r'\"(.+?)\"', v)
            costs = re.findall(r'\'(.+?)\'', v)
            self.variables_values[var] = values
            # Manage the case in which costs are not specified for all the allowed values
            if len(costs) == len(self.variables_values[var]):
                self.variables_costs[var] = map(int, costs)
            else:
                if len(costs) > 0:
                    # If the cost is specified for some it has to be specified for all the values
                    raise InputValidationException("Error: Configuration File - variable %s has %d costs instead of %d"
                                                   % (var, len(costs), len(self.variables_values[var])))
                # If there is no cost specified in the conf file it will not be considered
                self.variables_costs[var] = None
            try:
                types[var] = type[0][1:]
            except IndexError:
                # It's not a big deal ... just write it in the log
                common.LOG.debug("No type has been specified for variable %s" % var)

    def _normalise_cost_configuration(self):
        """
        Normalizes the costs of the variables
        :return: None
        """
        maximum = 0
        minimum = sys.maxint

        # Calculate max and min costs for all the variables
        for var in self.variables_values:
            if self.variables_costs[var]:
                local_max = max(self.variables_costs[var])
                local_min = min(self.variables_costs[var])
                if maximum < local_max:
                    maximum = local_max
                if minimum > local_min:
                    minimum = local_min
        # Normalisation
        for var in self.variables_values:
            if self.variables_costs[var]:
                local_max = max(self.variables_costs[var])
                local_min = min(self.variables_costs[var]) # it Is not a max/min normalization any more... can remove this

                for i in range(0, len(self.variables_costs[var])):
                    if local_max == 0:
                        self.variables_costs[var][i] = 0
                    else:
                        self.variables_costs[var][i] = (float(self.variables_costs[var][i]) * maximum / local_max)

    def _get_cost_for_variable(self, variable_name, variable_value):
        """
        Returns the cost correspondent to a variable
        :param variable_name: Name of the variable
        :param variable_value: Value of the variable
        :return: integer representing the cost
        """
        return self.variables_costs[variable_name][self.variables_values[variable_name].index(variable_value)]
