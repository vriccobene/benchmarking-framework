__author__ = 'vmriccox'

import os
import csv
import sys

import decision_maker
import weka_wrapper as weka


sys.path.append('../..')
from experimental_framework import common


class SmartDeployment():
    """
    Smart Deployment unit - it manages the deployment of new services according to the results obtained in the previous
    phase
    """

    def __init__(self):
        self.vtc_vnf_id = 1
        self.dm = decision_maker.DecisionMaker()
        self.results_directory = common.BASE_DIR + '/' + common.CONF_FILE.get_variable('General', 'results_directory')
        self.create_overall_csv()
        dt = weka.WekaWrapper.extract_decision_tree()
        self.dm.add_decision_tree(self.vtc_vnf_id, dt)
        self.allowed_network_intents = ['400M', '800M', '1G', '2G', '3G', '4G', '5G', '6G', '7G', '8G', '9G', '10G']

    def create_overall_csv(self):
        """

        :return:
        """
        data_files = self.list_source_files()
        titles = self.get_titles(data_files)
        overall = self.get_unique_file(data_files)
        self.write_overall_csv(overall, titles)
        # filename.split('_')[1].split('.')[0]

    def list_source_files(self):
        """

        :return:
        """
        # Read all the files with this pattern result_*.csv
        data_files = list()
        for dirname, dirnames, filenames in os.walk(self.results_directory):
            for filename in filenames:
                if filename.endswith(".csv") and filename.startswith("results_"):
                    data_files.append(os.path.join(dirname, filename))
        return data_files

    def get_titles(self, data_files):
        """

        :param data_files:
        :return:
        """
        titles = list()
        with open(data_files[0], 'rb') as csvfile:
            rows = csv.reader(csvfile, delimiter=';', quotechar='|')
            for row in rows:
                titles = row
                break
        return titles

    def get_unique_file(self, data_files):
        """

        :param data_files:
        :return:
        """
        overall = list()
        for f in data_files:
            titles = 0
            with open(f, 'rb') as csvfile:
                csv_file = csv.reader(csvfile, delimiter=';', quotechar='|')
                for row in csv_file:
                    if titles == 0:
                        titles = 1
                    else:
                        overall.append(row)
        return overall

    def write_overall_csv(self, row_list, titles):
        """

        :param row_list:
        :param titles:
        :return:
        """
        with open('overall.csv', 'wb') as csvfile:
            writer = csv.writer(csvfile, delimiter=',', quotechar='|')
            writer.writerow(titles)
            print titles
            for r in row_list:
                writer.writerow(r)

    def deploy_vtc(self, network_intent='3G'):
        """
        Deploys the virtual Traffic Classifier

        :param network_intent: Desired Target Throughput
        :return: None
        """
        if network_intent not in self.allowed_network_intents:
            raise ValueError("The network intent has to be one of the allowed values")

        self.dm.deploy_vnf(self.vtc_vnf_id, network_intent)

    @staticmethod
    def _sriov_tree_initialisation():
        # Leafs initialisation
        # NI = LESS means NI=0 - TODO: Fix this into the Weka module!!!
        l1 = decision_maker.DecisionTreeNode(variable_name='vm1-vnic1_type', condition_sign='=',
                                             variable_value='normal', network_intent=0)
        l2 = decision_maker.DecisionTreeNode(variable_name='vm1-vnic1_type', condition_sign='=',
                                             variable_value='direct', network_intent=400000)
        l3 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=',
                                             variable_value='direct', network_intent=0)
        l4 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=',
                                             variable_value='normal', network_intent=800000)
        l5 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=',
                                             variable_value='direct', network_intent=0)
        l6 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic3_type', condition_sign='=',
                                             variable_value='direct', network_intent=3000000)

        # Internal nodes initialisation
        n1 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=', variable_value='normal')
        n1.add_child(l1)
        n1.add_child(l2)

        n2 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic2_type', condition_sign='=', variable_value='normal')
        n2.add_child(n1)
        n2.add_child(l3)

        n3 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic3_type', condition_sign='=', variable_value='normal')
        n3.add_child(l4)
        n3.add_child(l5)

        n4 = decision_maker.DecisionTreeNode(variable_name='vm2-vnic2_type', condition_sign='=', variable_value='direct')
        n4.add_child(n3)
        n4.add_child(l6)

        decision_tree = decision_maker.DecisionTreeNode()
        decision_tree.add_child(n2)
        decision_tree.add_child(n4)
        return decision_tree