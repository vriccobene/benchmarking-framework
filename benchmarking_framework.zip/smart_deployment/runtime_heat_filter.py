__author__ = 'vmriccox'

from smart_deployment.decision_maker import DecisionMaker
from smart_deployment.decision_maker import DecisionTreeNode

# def decision_tree_creation():
#
#     for i in range(len(rules), 0, -1):
#         if leaf_index == rules[i-1][0]:
#             l = DecisionTreeNode(variable_name=rules[i-1][0], condition_sign='=', variable_value='normal',
#                                   network_intent=0)

def sriov_tree_initialisation():
    # Leafs initialisation
    # NI = LESS means NI=0 - TODO: Fix this into the Weka module!!!
    l1 = DecisionTreeNode(variable_name='vm1-vnic1_type', condition_sign='=', variable_value='normal',
                          network_intent=0)
    l2 = DecisionTreeNode(variable_name='vm1-vnic1_type', condition_sign='=', variable_value='direct',
                          network_intent=400000)
    l3 = DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=', variable_value='direct',
                          network_intent=0)
    l4 = DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=', variable_value='normal',
                          network_intent=800000)
    l5 = DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=', variable_value='direct',
                          network_intent=0)
    l6 = DecisionTreeNode(variable_name='vm2-vnic3_type', condition_sign='=', variable_value='direct',
                          network_intent=3000000)

    # Internal nodes initialisation
    n1 = DecisionTreeNode(variable_name='vm2-vnic1_type', condition_sign='=', variable_value='normal')
    n1.add_child(l1)
    n1.add_child(l2)

    n2 = DecisionTreeNode(variable_name='vm2-vnic2_type', condition_sign='=', variable_value='normal')
    n2.add_child(n1)
    n2.add_child(l3)

    n3 = DecisionTreeNode(variable_name='vm2-vnic3_type', condition_sign='=', variable_value='normal')
    n3.add_child(l4)
    n3.add_child(l5)

    n4 = DecisionTreeNode(variable_name='vm2-vnic2_type', condition_sign='=', variable_value='direct')
    n4.add_child(n3)
    n4.add_child(l6)

    decision_tree = DecisionTreeNode()
    decision_tree.add_child(n2)
    decision_tree.add_child(n4)
    return decision_tree


vnf_id = 1
dm = DecisionMaker()
dm.add_decision_tree(vnf_id, sriov_tree_initialisation())
dm.deploy_vnf(vnf_id, 3000000)
